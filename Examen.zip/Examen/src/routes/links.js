const express= require('express');
const router= express.Router();
const pool= require("../database");

router.get('/ver/:daid', async (req, res)=>{
    const {daid}=req.params;
    const data=await pool.query('SELECT * FROM imanol WHERE daid=?',[daid]);
    res.render('links/ver', {imanol:data[0]});    
});



router.get('/prueba', async (req, res)=>{
    const data= await pool.query('SELECT * FROM imanol');
    res.render('links/prueba', {data});    
});


router.get('/carrito', async (req, res)=>{
    const data= await pool.query('SELECT * FROM imanol');
    res.render('links/carrito', {data});    
});

router.get('/editar/:id', async (req,res)=>{
    const {id}=req.params;
    const alumnos=await pool.query('SELECT * FROM imanol WHERE Id_Alumno=?',[id]);
    res.render('links/editar', {alumno:alumnos[0]});
});
router.post('/carrito/:id', async (req,res)=>{
    const {id}=req.params;
    const {nombre, apellidos, id_materia}=req.body;
    const editarAlumno={nombre, apellidos, id_materia};
    await pool.query('UPDATE imanol SET ? WHERE id=?', [editarAlumno,id]);
    res.redirect('/links/carrito');
});


router.post('/carrito',async (req,res) => {
    const {nombre,apellidos,id_materia}=req.body;
    const nuevoAlumno={nombre,apellidos,id_materia};
    await pool.query('INSERT INTO imanol SET?',[nuevoAlumno]);
    res.redirect('links/carrito');
});


module.exports=router;


