const express= require('express');
const router= express.Router();
const pool= require("../database");
router.get('/',async(req,res)=>{
    const data =await pool.query('select * from imanol');
    res.json(data);
});
router.get('/:id',async(req,res)=>{
    const {id} = req.parms;
    const data =await pool.query('select * from imanol where id=?',[id]);
    res.json(data);
});
router.delete('/borrar/:id',async(req,res)=>{
    const {id} = req.parms;
    const data =await pool.query('delete from imanol where id=?',[id]);
    res.json({'respuesta':'datos borrados'}
    );
});

router.post('/agregar',async(req,res)=>{
    const {nombre,apellidos,id_materia}=req.body;
    const nuevoAlumno = {nombre,apellidos,id_materia};
    await pool.query('insert into imanol set ?',[nuevoAlumno]);
    res.json({'respuesta':'datos guardados'});
});
router.put('/editar/:id',async(req,res)=>{
    const {id}=req.params;
    const {nombre, apellidos, id_materia}=req.body;
    const editarAlumno={nombre, apellidos, id_materia};
    const alumnos =await pool.query('UPDATE imanol SET ? WHERE id=?',[id]);
    res.json(bodyParser.json);
});
module.exports=router;