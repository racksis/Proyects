module.exports = {
   database: {
       connectionLimit: 10,
       host:'tlatoanicloud.com',
       user:'tlatoani_udl',
       password:'Udl_2019+',
       database:'tlatoani_swiftdb'
   }};
